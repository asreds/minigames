import React from "react";

type Props = {
  setCount: Function;
};

type CountData = {
  x: number,
  y: number,
}

function FormCount({ setCount }: Props) {
  
  const [count, setCountNumber] = React.useState<CountData>({x: 0, y: 0});

  const handleChange = (type: string, e: React.ChangeEvent<HTMLInputElement>) => {
    let tempCount:any = count;
    tempCount[type] = Number(e.target.value);
    setCountNumber({...tempCount});
  }

  return (
    <form className="row row-cols-lg-auto g-3 align-items-center">
      <div className="col-12">
        <label className="visually-hidden" htmlFor="countBox">
          Preference
        </label>
        <input
          type="number"
          className="form-control"
          id="countBox"
          placeholder="x Box"
          onChange={(e) => {
            handleChange('x', e)
          }}
        />
      </div>
      <div className="col-12">
        <label className="visually-hidden" htmlFor="countBox">
          Preference
        </label>
        <input
          type="number"
          className="form-control"
          id="countBox"
          placeholder="y Box"
          onChange={(e) => {
            handleChange('y', e)
          }}
        />
      </div>
      <div className="col-12">
        <button
          type="button"
          className="btn btn-primary"
          onClick={() => setCount(count)}
        >
          Submit
        </button>
      </div>
    </form>
  );
}

export default FormCount;
