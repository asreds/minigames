import React from "react";

type Props = {
  count: any;
};

function Box({ count }: Props) {
  const generateBoxX = (y: number) => {
    return [...Array(count.x)].map((x, idx) => {
      return <td key={`x-${idx}`}>
        <button type="button" className="btn btn-light">Light</button>
      </td>;
    });
  };
  const generateBox = () => {
    console.log(count.y)
    return [...Array(count.y)].map((y, idx) => {
      return (
        <tr key={`y-${idx}`}>
          {generateBoxX(idx)}
        </tr>
      );
    });
  };
  console.log(count.y)
  return (
    <div>
      <table className="table table-bordered">{generateBox()}</table>
    </div>
  );
}

export default Box;
