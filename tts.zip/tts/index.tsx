import React from "react";
import Box from "./components/box";
import FormCount from "./components/formCount";

type CountData = {
  x: number,
  y: number,
}

function TtsIndex() {
   const [countBox, setCountBox] = React.useState<CountData>({x: 0, y:0});
  return (
    <div className="container">
      <div className="row">
        <div className="col-lg-12">
          <FormCount setCount={setCountBox} />
        </div>
      </div>

      <h1>Please insert your answer on this box</h1>
      <div className="row">
        <div className="col-lg-12">
          <Box count={countBox}/>
        </div>
      </div>
    </div>
  );
}

export default TtsIndex;
